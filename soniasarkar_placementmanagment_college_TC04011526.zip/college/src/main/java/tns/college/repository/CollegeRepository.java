package tns.college.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import tns.college.entity.College;
public interface CollegeRepository extends JpaRepository<College, Long>{

}


